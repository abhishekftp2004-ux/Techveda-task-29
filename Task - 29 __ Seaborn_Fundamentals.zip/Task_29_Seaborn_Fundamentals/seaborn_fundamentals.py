"""
Task 29: Seaborn Fundamentals
Efficient, reusable implementation for six statistical visualizations.

Run from this folder:
    python -m pip install -r requirements.txt
    python seaborn_fundamentals.py

The included CSV files are illustrative teaching samples, not official datasets.
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
OUTPUT_DIR = ROOT / "visualizations"
OUTPUT_DIR.mkdir(parents=True, exist_ok=True)

# Set one consistent visual theme for all charts.
sns.set_theme(style="whitegrid", palette="deep", context="notebook")

def load_data():
    """Load datasets once, validate required columns, and return DataFrames."""
    passengers = pd.read_csv(DATA_DIR / "titanic_sample.csv")
    flowers = pd.read_csv(DATA_DIR / "iris_sample.csv")

    passenger_required = {"Pclass", "Survived", "Age", "Fare"}
    flower_required = {"petal_length", "petal_width", "species"}
    if not passenger_required.issubset(passengers.columns):
        raise ValueError(f"Passenger data must contain: {sorted(passenger_required)}")
    if not flower_required.issubset(flowers.columns):
        raise ValueError(f"Flower data must contain: {sorted(flower_required)}")
    return passengers, flowers

def save_figure(fig, filename):
    """Apply consistent spacing, save at print-friendly resolution, then close."""
    fig.tight_layout()
    fig.savefig(OUTPUT_DIR / filename, dpi=160, bbox_inches="tight")
    plt.close(fig)

def make_countplot(passengers):
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.countplot(data=passengers, x="Pclass", hue="Survived", ax=ax)
    ax.set(title="Passenger Counts by Class and Survival",
           xlabel="Passenger class (1 = first, 3 = third)",
           ylabel="Number of records")
    ax.legend(title="Survived", labels=["No (0)", "Yes (1)"])
    save_figure(fig, "01_countplot.png")

def make_boxplot(passengers):
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.boxplot(data=passengers, x="Pclass", y="Fare", ax=ax, color="steelblue")
    ax.set(title="Fare Distribution by Passenger Class",
           xlabel="Passenger class", ylabel="Fare (illustrative units)")
    save_figure(fig, "02_boxplot.png")

def make_histogram(passengers):
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.histplot(data=passengers, x="Age", hue="Survived", bins=18,
                 kde=True, element="step", common_norm=False, ax=ax)
    ax.set(title="Age Distribution by Survival Status",
           xlabel="Age", ylabel="Count")
    save_figure(fig, "03_histogram.png")

def make_scatterplot(flowers):
    fig, ax = plt.subplots(figsize=(8, 5))
    sns.scatterplot(data=flowers, x="petal_length", y="petal_width",
                    hue="species", style="species", s=55, ax=ax)
    ax.set(title="Petal Length vs Petal Width",
           xlabel="Petal length (cm)", ylabel="Petal width (cm)")
    save_figure(fig, "04_scatterplot.png")

def make_heatmap(flowers):
    numeric = flowers.select_dtypes(include="number")
    corr = numeric.corr()  # compute once and reuse
    fig, ax = plt.subplots(figsize=(8, 6))
    sns.heatmap(corr, annot=True, fmt=".2f", cmap="vlag",
                center=0, square=True, ax=ax)
    ax.set_title("Correlation Heatmap — Flower Measurements")
    save_figure(fig, "05_heatmap.png")

def make_pairplot(flowers):
    grid = sns.pairplot(
        flowers,
        hue="species",
        vars=["sepal_length", "sepal_width", "petal_length", "petal_width"],
        corner=True,
        plot_kws={"s": 18, "alpha": 0.75},
    )
    grid.fig.suptitle("Pairplot of Flower Measurements", y=1.02)
    grid.savefig(OUTPUT_DIR / "06_pairplot.png", dpi=140, bbox_inches="tight")
    plt.close(grid.fig)

def print_summaries(passengers, flowers):
    print(f"Passenger sample: {passengers.shape[0]} rows × {passengers.shape[1]} columns")
    print(f"Flower sample:    {flowers.shape[0]} rows × {flowers.shape[1]} columns")
    print("\nSurvival proportion by passenger class:")
    print(passengers.groupby("Pclass", observed=True)["Survived"].mean().round(3))
    print("\nMean petal measurements by species:")
    print(flowers.groupby("species", observed=True)[["petal_length", "petal_width"]].mean().round(2))
    print(f"\nCharts saved to: {OUTPUT_DIR}")

def main():
    passengers, flowers = load_data()
    make_countplot(passengers)
    make_boxplot(passengers)
    make_histogram(passengers)
    make_scatterplot(flowers)
    make_heatmap(flowers)
    make_pairplot(flowers)
    print_summaries(passengers, flowers)

if __name__ == "__main__":
    main()
